/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

/**
 *
 * @author 111
 */
public class PurchaseItems extends BuyerOrganization {
    private String PurchaseItemName;
    private String PurchaseItemNumber;

    public String getPurchaseItemName() {
        return PurchaseItemName;
    }

    public void setPurchaseItemName(String PurchaseItemName) {
        this.PurchaseItemName = PurchaseItemName;
    }

    public String getPurchaseItemNumber() {
        return PurchaseItemNumber;
    }

    public void setPurchaseItemNumber(String PurchaseItemNumber) {
        this.PurchaseItemNumber = PurchaseItemNumber;
    }
    
    
    
    
    
    
}

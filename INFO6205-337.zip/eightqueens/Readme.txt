Genetic Algorithm Solving Eight Queen Problems
Team number��337
Team Name:Bingling

Problem
I created a genetic algorithm to find a solution to the Eight Queens Problem. 
The problem poses the situation: Eight queens problem is an NP problem, and its goal is to place the chess queen on the eight 8X8 chessboard so that no one can capture any other queen Queen, 
that each row has only one queen in each column, each of Angle online at most one queen.

   Steps:
   1. first randomly generate a certain number of chromosomes;
   2. Select better individual chromosomes from the population;
   3. two parent chromosomes are generated in sequence for the two parent chromosomes. In theory, the daughter chromosome will gradually carry out more excellent chromosomes with excellent parent chromosomes;
   4. a gene encoding a random variation chromosome;
   By performing the above steps 2, 3, and 4 in a loop, the optimal solution is finally obtained.
package eightqueensGA;

import static org.junit.Assert.assertEquals;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.junit.Test;

public class testcrossover {
	private static List<Chromosome> chromo = new LinkedList<Chromosome>();
	Random r = new Random();
	String solution1 = "00000000";
	String solution2 = "66666666";
	String solution01 = "11111111";
	String solution02 = "77777777";
	String solution001 = "33333333";
	String solution002 = "44444444";
	String solution011 = "01234567";
	String solution012 = "76543210";
	
	@SuppressWarnings("unused")
	private void crossOver() {
		int i = -1;
		while (i < chromo.size())
		{
			int ranIndex = 1 + r.nextInt(8 - 1);
			Chromosome c1 = chromo.get(i);
			Chromosome c2 = chromo.get(i + 1);
//			solution1 = c1.getSolution();
//			solution2 = c2.getSolution();
			String temp1 = solution1.substring(0, ranIndex) + solution2.substring(ranIndex, solution2.length());
			String temp2 = solution2.substring(0, ranIndex) + solution1.substring(ranIndex, solution1.length());
			c1.setSolution(temp1);
			c2.setSolution(temp2);
			i = i + 2;
		}
	}

	@Test
	public void testCrossover01() {
		// Random r = new Random();
		// int n = r.nextInt();

		String temp1 = solution1.substring(0, 4) + solution2.substring(4, solution2.length());
		String temp2 = solution2.substring(0, 4) + solution1.substring(4, solution1.length());

		assertEquals("00006666", temp1);
		assertEquals("66660000", temp2);

	}
	
	@Test
	public void testCrossover02() {
		// Random r = new Random();
		// int n = r.nextInt();
		String temp01 = solution01.substring(0, 4) + solution02.substring(4, solution02.length());
		String temp02 = solution02.substring(0, 4) + solution01.substring(4, solution01.length());

		assertEquals("11117777", temp01);
		assertEquals("77771111", temp02);

	}
	@Test
	public void testCrossover03() {
		
		String temp001 = solution001.substring(0, 4) + solution002.substring(4, solution002.length());
		String temp002 = solution002.substring(0, 4) + solution001.substring(4, solution001.length());

		assertEquals("33334444", temp001);
		assertEquals("44443333", temp002);

	}
	@Test
	public void testCrossover04() {
		
		String temp011 = solution011.substring(0, 4) + solution012.substring(4, solution012.length());
		String temp012 = solution012.substring(0, 4) + solution011.substring(4, solution011.length());

		assertEquals("01233210", temp011);
		assertEquals("76544567", temp012);
	}
}